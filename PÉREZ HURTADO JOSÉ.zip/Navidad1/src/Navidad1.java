public class Navidad1 {

    public static void main(String args[]){

        Navidad1Clase n = new Navidad1Clase();

        System.out.println("\t##################");
        System.out.println("\t# IMC CALCULATOR #");
        System.out.println("\t##################\n");

        n.readNum();
        n.getIMC();



        System.out.println("\nHasta luego Lucas");
    }
}





