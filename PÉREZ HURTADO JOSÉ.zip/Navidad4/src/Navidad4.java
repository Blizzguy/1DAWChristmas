

public class Navidad4 {

    public static void main(String[] args) {

        Navidad4Clase n = new Navidad4Clase();

        System.out.println("BASE DE DATOS DE NOTAS DE PROGRAMACIÓN");
        System.out.println("--------------------------------------\n");

        n.readNum();
        n.getNota();

        System.out.println("\nHasta luego Lucas");
    }
}
