


public class Navidad5 {

    public static void main(String[] args){
        Navidad5Clase n = new Navidad5Clase();

        System.out.println("\n PROGRAMA DE TRADUCCIÓN DE NÚMEROS (del 20 al 99) ");

        System.out.println("//////////////////////////////////////////////////\n");

        n.readNum();
        n.getNumName();

        System.out.println("\n\tHasta luego Lucas.");

    }
}

