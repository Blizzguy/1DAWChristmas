

public class Navidad6 {
    public static void main(String[] args) {

        Navidad6Clase n = new Navidad6Clase();

        System.out.println("PROGRAMA DE IDENTIFICACIÓN DE NÚMERO");
        System.out.println("////////////////////////////////////");

        n.readNum();
        n.getResultado();


        System.out.println("\n\nHasta luego Lucas.");

    }
}
