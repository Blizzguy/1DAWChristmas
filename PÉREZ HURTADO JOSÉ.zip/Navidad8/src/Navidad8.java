

class Navidad8 {

    public static void main(String[] args) {

        Navidad8Clase n = new Navidad8Clase();

        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("LISTA DE ALUMNOS DE LA ESCUELA SAN VALENTÍN");
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");

        n.readNum();
        n.getResultado();



        System.out.println("\n\tHasta luego Lucas.");



    }
}
