
public class Navidad9 {

    public static void main(String arg[]){

        Navidad9Clase n = new Navidad9Clase();

        System.out.println("\t==================");
        System.out.println("\t= NUMEROS PRIMOS =");
        System.out.println("\t==================\n");

        n.readNum();
        n.getPrimo();

        System.out.println("\n\n\tHasta luego lucas.");

    }

}
